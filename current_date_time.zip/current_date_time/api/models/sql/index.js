/* eslint-disable no-unused-expressions */
/* eslint-disable no-irregular-whitespace */

'use strict';

const fs = require('fs');
const path = require('path');
const Sequelize = require('sequelize');

const basename = path.basename(module.filename);
const env = process.env.NODE_ENV || 'development';
const config = require('../../../config/config.json')['mysql'][env];

console.log(`####################### MYSQL ENV###################### ${env}`);
const db = {};
let connection;


global.connection;

if (config.use_env_variable) {
    connection = new Sequelize(process.env[config.use_env_variable]);
} else {
    // config.database, config.username, config.password
    // console.log("CHECK : "+util.inspect(config));
    connection = new Sequelize(config.database, config.user, config.password, config);
}

// var connection = new Sequelize('devopsdashboard','devops','8aSFYqtHXT');

// Checking connection status
connection.authenticate().then((conn) => {
    global.connection;
    // console.log(`Connection has been established successfully :${process.env.NODE_ENV} connection ${conn}`);
    console.log(`Connection has been established successfully :${process.env.NODE_ENV}`);
}).catch((err) => {
    console.log('Error while connect : ', err);
});

console.log('** basename ** ', basename);

fs.readdirSync(__dirname)
    .filter((file) => {
        console.log(`FILEISSUE${file}`);
        return (file.indexOf('.') !== 0) && (file !== basename) && (file.slice(-3) === '.js');
    })
    .forEach((file) => {
        // const model = connection.import(path.join(__dirname, file));
        // db[model.name] = model;

        const model = require(path.join(__dirname, file))(connection, Sequelize)
        db[model.name] = model;

    });

Object.keys(db).forEach((modelName) => {
    if (db[modelName].associate) {
        db[modelName].associate(db);
    }
});

db.connection = connection;
db.Sequelize = Sequelize;
module.exports = db;
