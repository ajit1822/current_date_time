const MESSAGES = require('../../../util/message_code.json').dateTime;
const {getDateTimeParams} = require('../../../../service/v2/date_time/date_time');

function getCurrentDateTime(req,res){
    try{
        const mainFn = async () => {
            const response = await getDateTimeParams();
            const responseReceived = response !== null ? 200 : 400;
            res.status(responseReceived).send({
                status: responseReceived,
                message: MESSAGES.find[responseReceived],
                data: response,
            })
        }
        mainFn()
            .catch((error) => {
                console.log('ERROR :', error);
                res.status(500).send({
                    status: 500,
                    message: MESSAGES.find[500],
                    data: null
                })
            })
    }catch(error){
        console.log('ERROR :', error);
        res.status(500).send({
            status: 500,
            message: MESSAGES.find[500],
            data: null
        })
    }
}

module.exports = {
    getCurrentDateTime,
}