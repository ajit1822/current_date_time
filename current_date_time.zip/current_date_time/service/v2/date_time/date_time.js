const moment = require('moment');
const momentTz = require('moment-timezone');
const getDateTimeParams = async()=>{
    try{
        // const dateTimeResponse = moment.utc().format('YYYY-MM-DD HH:mm:ss');
        // return dateTimeResponse;
        return momentTz().tz('Europe/London').format('YYYY-MM-DD HH:mm:ss');
    }catch(error){
        throw error;
    }
}

module.exports = {
    getDateTimeParams,
}