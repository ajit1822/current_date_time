const app = require('express')();
// const models = require('./app/models/sql/index.js');
const models = require('../../api/models/sql/index');

module.exports = {
    bootstrap: () => {
        const port = process.env.PORT || 10010;
        models.connection.sync().then(() => {
            app.listen(port);
        });
    },
};
